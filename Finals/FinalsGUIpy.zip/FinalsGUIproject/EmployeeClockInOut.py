import json
from tkinter import messagebox, filedialog
from tkinter import PhotoImage
import customtkinter as ctk
from PIL import Image, ImageTk, ImageDraw
import os
import time
from datetime import datetime
import csv

ctk.set_appearance_mode("dark")

app = ctk.CTk()
app.title("Employee Clock-in Clock-out System")


def maximize_window():
    app.state("zoomed")
app.after(100, maximize_window)

app.resizable(True, True)

# Load the background image
bg_image_path = "bluebackground1.png"
bg_image = Image.open(bg_image_path)
bg_image = bg_image.resize((app.winfo_screenwidth(), app.winfo_screenheight()))
bg_image_tk = ImageTk.PhotoImage(bg_image)
bg_label = ctk.CTkLabel(app, image=bg_image_tk)
bg_label.place(relwidth=1, relheight=1)

current_user = {"username": "", "full_name": ""}

# LOGIN FRAME
login_frame = ctk.CTkFrame(master=app, fg_color="#121F34", border_color="#C79D2A", border_width=2 )
login_frame.pack(pady=20, padx=400, fill="both", expand=True)

login_label = ctk.CTkLabel(master=login_frame,
                           text="Login",
                           font=("Arial", 50),
                           text_color="#C79D2A")
login_label.pack(pady=40)

username_text = ctk.CTkEntry(master=login_frame,
                             placeholder_text="Username",
                             width=300, height=50,
                             font=("Arial", 18),
                             placeholder_text_color="#C79D2A",
                             fg_color="#0D1B2A", border_color="#C79D2A")
username_text.pack(pady=10, padx=20)

password_text = ctk.CTkEntry(master=login_frame,
                             placeholder_text="Password",
                             show="*", width=300,
                             height=50, font=("Arial", 18),
                             placeholder_text_color="#C79D2A",
                             fg_color="#0D1B2A", border_color="#C79D2A")
password_text.pack(pady=10, padx=20)

login_button = ctk.CTkButton(master=login_frame,
                             text="Login",
                             width=300, height=50,
                             corner_radius=32,
                             fg_color="#C79D2A",
                             border_color="#0D1B2A",
                             border_width=2,
                             font=("Arial", 18),
                             text_color="#0D1B2A")
login_button.pack(pady=10)

register_button = ctk.CTkButton(master=login_frame,
                                text="Register",
                                width=300, height=50,
                                corner_radius=32,
                                fg_color="transparent",
                                border_color="#C79D2A",
                                border_width=2,
                                font=("Arial", 18),
                                text_color="#C79D2A")
register_button.pack(pady=10)


# REGISTER FRAME
register_frame = ctk.CTkFrame(master=app, fg_color="#121F34", border_color="#C79D2A", border_width=2 )

register_label = ctk.CTkLabel(master=register_frame,
                              text="Register",
                              font=("Arial", 50),
                              text_color="#C79D2A")
register_label.pack(pady=40)

new_username = ctk.CTkEntry(master=register_frame,
                             placeholder_text="New Username",
                             width=300, height=50,
                             font=("Arial", 18),
                             placeholder_text_color="#C79D2A",
                             fg_color="#0D1B2A", border_color="#C79D2A")
new_username.pack(pady=10, padx=20)

new_password = ctk.CTkEntry(master=register_frame,
                             placeholder_text="New Password",
                             show="*", width=300,
                             height=50, font=("Arial", 18),
                             placeholder_text_color="#C79D2A",
                             fg_color="#0D1B2A", border_color="#C79D2A")
new_password.pack(pady=10, padx=20)

confirm_password = ctk.CTkEntry(master=register_frame,
                                 placeholder_text="Confirm Password",
                                 show="*", width=300,
                                 height=50, font=("Arial", 18),
                                 placeholder_text_color="#C79D2A",
                                 fg_color="#0D1B2A", border_color="#C79D2A")
confirm_password.pack(pady=10, padx=20)


#
first_name_entry = ctk.CTkEntry(master=register_frame,
                                 placeholder_text="First Name",
                                 width=300,
                                 height=50, font=("Arial", 18),
                                 placeholder_text_color="#C79D2A",
                                 fg_color="#0D1B2A", border_color="#C79D2A")
first_name_entry.pack(pady=10, padx=20)


last_name_entry = ctk.CTkEntry(master=register_frame,
                                 placeholder_text="Last Name",
                                 width=300,
                                 height=50, font=("Arial", 18),
                                 placeholder_text_color="#C79D2A",
                                 fg_color="#0D1B2A", border_color="#C79D2A")
last_name_entry.pack(pady=10, padx=20)
#


submit_button = ctk.CTkButton(master=register_frame,
                               text="Register",
                             width=300, height=50,
                             corner_radius=32,
                             fg_color="#C79D2A",
                             border_color="#0D1B2A",
                             border_width=2,
                             font=("Arial", 18),
                             text_color="#0D1B2A")
submit_button.pack(pady=10)

back_to_login_button = ctk.CTkButton(master=register_frame,
                                      text="Back to Login",
                                     width=300, height=50,
                                     corner_radius=32,
                                     fg_color="transparent",
                                     border_color="#C79D2A",
                                     border_width=2,
                                     font=("Arial", 18),
                                     text_color="#C79D2A")
back_to_login_button.pack(pady=10)


#CLOCK IN/OUT FRAME
"""clock_in_frame = ctk.CTkFrame(master=app, fg_color="#121F34", border_color="#C79D2A", border_width=2)
clock_in_frame.grid_rowconfigure(0, weight=1)
clock_in_frame.grid_columnconfigure(0, weight=1)   # left column (narrow)
clock_in_frame.grid_columnconfigure(1, weight=3)   # right column (wider)

# left box (vertical panel)
left_box = ctk.CTkFrame(master=clock_in_frame, fg_color="#0D1B2A", corner_radius=10)
left_box.grid(row=0, column=0, sticky="nsew", padx=(20, 10), pady=20)

# right box (main content area)
right_box = ctk.CTkFrame(master=clock_in_frame, fg_color="#0D1B2A", corner_radius=10)
right_box.grid(row=0, column=1, sticky="nsew", padx=(10, 20), pady=20)"""
#clock_frame = ctk.CTkFrame(master=app)
# CLOCK IN/OUT FRAME
clock_in_frame = ctk.CTkFrame(master=app, fg_color="#121F34", border_color="#C79D2A", border_width=2)
clock_in_frame.grid_rowconfigure(0, weight=1)
clock_in_frame.grid_columnconfigure(0, weight=1)   # left column (narrow)
clock_in_frame.grid_columnconfigure(1, weight=3)   # right column (wider)
# left box
left_box = ctk.CTkFrame(master=clock_in_frame, fg_color="#0D1B2A", corner_radius=10)
left_box.grid(row=0, column=0, sticky="nsew", padx=(20, 10), pady=20)
weekly_total_seconds = 0
# for image
# 1. Load & resize your avatar PIL image
avatar_pil = Image.open("default.jpg").resize((100,100), Image.LANCZOS)

# 2. Create a circular mask and apply as alpha
mask = Image.new("L", (100,100), 0)
draw = ImageDraw.Draw(mask)
draw.ellipse((0,0,100,100), fill=255)
avatar_pil.putalpha(mask)

# 3. Wrap it in CTkImage
avatar_ctk = ctk.CTkImage(light_image=avatar_pil, dark_image=avatar_pil, size=(100,100))

# 4. Create a rounded-frame container with a border
AV_SIZE = 100
BORDER = 4
TOTAL = AV_SIZE + BORDER*2      # 108

# Create the frame that will hold the avatar
avatar_frame = ctk.CTkFrame(
    left_box,
    width=TOTAL,
    height=TOTAL,
    corner_radius=TOTAL//2,     # 54
    border_width=BORDER,
    border_color="",
    fg_color="#0D1B2A",
)
# Prevent the frame from resizing to its content
avatar_frame.pack_propagate(False)
avatar_frame.pack(pady=(20,15))

# Now center the avatar image inside:
def update_avatar_image(img_path):
    avatar_pil = Image.open(img_path).resize((100,100), Image.LANCZOS)
    mask = Image.new("L", (100,100), 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0,0,100,100), fill=255)
    avatar_pil.putalpha(mask)

    avatar_ctk = ctk.CTkImage(light_image=avatar_pil, dark_image=avatar_pil, size=(100,100))
    avatar_label.configure(image=avatar_ctk)
    avatar_label.image = avatar_ctk  # Keep a reference


# Now center the avatar image inside:
avatar_label = ctk.CTkLabel(
    avatar_frame,
    image=avatar_ctk,
    text=""
)
avatar_label.place(relx=0.5, rely=0.5, anchor="center")

# Make avatar clickable
avatar_label.bind("<Button-1>", lambda e: change_avatar())
# for image up

#
logout_button = ctk.CTkButton(left_box, text="Log Out",
                             height=20,
                              corner_radius=32,
                              fg_color="transparent",
                              border_color="#C79D2A",
                              border_width=2,
                              font=("Arial", 18),
                              text_color="#C79D2A")
logout_button.pack(pady=(10, 15))
#
user_label = ctk.CTkLabel(left_box, text="", font=("Arial", 30))
user_label.pack(pady=(20, 10))

clock_in_button = ctk.CTkButton(left_box, text="Clock In",
                            height=40,
                             fg_color="#09c60f",
                             border_color="#0D1B2A",
                             border_width=2,
                             font=("Arial", 18),
                             text_color="#0D1B2A" )
clock_in_button.pack(pady=(10, 15))
# clock_out_button.pack() only after user clocks in
clock_out_button = ctk.CTkButton(left_box, text="Clock Out",
                             height=40,
                             fg_color="#e82222",
                             border_color="#0D1B2A",
                             border_width=2,
                             font=("Arial", 18),
                             text_color="#0D1B2A")
clock_out_button.pack(pady=(10, 15))


time_label = ctk.CTkLabel(left_box,font=("Arial", 26))
time_label.pack(pady=(70,0.1))

# right box
right_box = ctk.CTkFrame(master=clock_in_frame, fg_color="#0D1B2A", corner_radius=10)
right_box.grid(row=0, column=1, sticky="nsew", padx=70, pady=25)

start_time = None
today_total_seconds = 0

today_label = ctk.CTkLabel(right_box, text_color="#09c60f" , text="Current session: 0h 0m" , font=("Arial", 32))
today_label.pack(pady=(20,90))






def update_time():
    current_time = datetime.now().strftime("%b %d, %Y %I:%M:%S %p")  # Format date and time
    time_label.configure(text=f"{current_time}", text_color="#C79D2A")
    app.after(1000, update_time)  # Update every second

# Call the function to start updating time
update_time()




#FUNCTIONS
# Clicking Register Function
def show_register_frame():
    login_frame.pack_forget()
    register_frame.pack(pady=20, padx=400, fill="both", expand=True)

# Clicking Back to Login Function
def show_login_frame():
    register_frame.pack_forget()
    login_frame.pack(pady=20, padx=400, fill="both", expand=True)

#
current_user = {}
# REGISTRATION LOGIC FUNCTION
def register_user():
    username = new_username.get()
    password = new_password.get()
    confirm_pw = confirm_password.get()
    first_name = first_name_entry.get()
    last_name = last_name_entry.get()

    if not all([username, password, confirm_pw, first_name, last_name]):
        messagebox.showerror("Missing Info", "Please fill in all fields.")
        return

    if password != confirm_pw:
        messagebox.showerror("Error", "Passwords do not match. Please try again.")
        return

    # Check if username already exists
    if os.path.exists("user_data.csv"):
        with open("user_data.csv", "r", newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row["username"] == username:
                    messagebox.showerror("Error", "Username already exists. Please choose another.")
                    return

    # If it's a new username, add it
    file_exists = os.path.isfile('user_data.csv')
    with open('user_data.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(['username', 'password', 'first_name', 'last_name', 'avatar_path'])
        writer.writerow([username, password, first_name, last_name, ""])

    messagebox.showinfo("Success", f"User '{username}' registered successfully!")
    show_login_frame()

def login_user():
    login_username = username_text.get()
    login_password = password_text.get()

    if not login_username or not login_password:
        messagebox.showerror("Missing Info", "Please fill in all fields.")
        return

    if not os.path.exists("user_data.csv"):
        messagebox.showerror("Error", "User database not found. Please register first.")
        return

    with open("user_data.csv", "r", newline='') as file:
        reader = csv.DictReader(file)
        for row in reader:
            if row['username'] == login_username and row['password'] == login_password:
                full_name = f"{row['first_name']} {row['last_name']}"
                user_label.configure(text=full_name)

                current_user["username"] = login_username
                current_user["full_name"] = full_name

                load_user_avatar(login_username)  # ✅ Load the saved avatar

                login_frame.pack_forget()
                clock_in_frame.pack(pady=30, padx=30, fill="both", expand=True)

                clock_in_button.configure(state="normal")
                clock_out_button.configure(state="disabled")
                load_user_logs(login_username)
                load_session_data(login_username)  # ✅ Load session data

                # ✅ Load and show avatar
                avatar_path = load_user_avatar(login_username)
                if avatar_path and os.path.exists(avatar_path):
                    avatar_image = ctk.CTkImage(Image.open(avatar_path), size=(100, 100))
                    avatar_label.configure(image=avatar_image, text="")  # assumes you have avatar_label defined

                update_today_timer()
                return
    messagebox.showerror("Login Failed", "Account not found or incorrect credentials.")
# log out function
def log_out():
    global start_time, today_total_seconds, weekly_total_seconds

    if start_time is not None:
        clock_out()  # Auto clock out if user is still clocked in

    # Clear session data
    start_time = None
    today_total_seconds = 0
    weekly_total_seconds = 0
    current_user.clear()

    # Hide clock-in frame and show login frame
    clock_in_frame.pack_forget()
    login_frame.pack(pady=20, padx=400, fill="both", expand=True)

    # Reset UI elements if needed
    user_label.configure(text="")
    today_label.configure(text="Current session: 0h 0m")
    clock_in_out_log.clear()
    update_log_display()
# today timer function
def update_today_timer():
    total = today_total_seconds
    if start_time:
        total += (datetime.now() - start_time).total_seconds()

    hours, remainder = divmod(total, 3600)
    minutes, seconds = divmod(remainder, 60)

    today_label.configure(text=f"Current session: {int(hours)}h {int(minutes)}m {int(seconds)}s")
    app.after(1000, update_today_timer)


# Define a new label to display the log
clock_in_out_log_label = ctk.CTkLabel(right_box, font=("Arial", 24))
clock_in_out_log_label.pack(pady=(5, 50))

# A list to keep track of clock-in and clock-out logs
clock_in_out_log = []


# clock in logic function
def clock_in():
    global start_time
    if start_time is not None:  # ✅ Prevent double clock-in
        return
    clock_in_count, _ = get_today_clock_counts()

    if clock_in_count >= 5:
        messagebox.showwarning("Limit Reached", "You have already clocked in 5 times today.")
        return

    if start_time is not None:
        messagebox.showwarning("Already Clocked In", "You are already clocked in.")
        return

    start_time = datetime.now()
    clock_in_out_log.append(f"Clocked in: {start_time.strftime('%b %d at %I:%M %p')}")
    update_log_display()

    save_session_data(username_text.get())  # ✅ Save session start time

    clock_in_button.configure(state="disabled")
    clock_out_button.configure(state="normal")

# clock out logic function (modified to add logs)
def clock_out():
    global start_time, today_total_seconds, weekly_total_seconds

    if start_time is None:
        messagebox.showwarning("Not Clocked In", "You haven't clocked in yet.")
        return

    _, clock_out_count = get_today_clock_counts()

    if clock_out_count >= 5:

        return

    end_time = datetime.now()
    session_duration = (end_time - start_time).total_seconds()

    today_total_seconds += session_duration
    weekly_total_seconds += session_duration

    start_time = None
    save_session_data(current_user["username"])

    clock_in_out_log.append(f"Clocked out: {end_time.strftime('%b %d at %I:%M %p')}")
    update_log_display()

    # Update labels
    total_hours, remainder = divmod(today_total_seconds, 3600)
    total_minutes, _ = divmod(remainder, 60)
    today_label.configure(text=f"Current session: {int(total_hours)}h {int(total_minutes)}m")

    weekly_hours, weekly_remainder = divmod(weekly_total_seconds, 3600)
    weekly_minutes, _ = divmod(weekly_remainder, 60)

    save_user_logs(current_user["username"])

    delete_session_data(username_text.get())  # ✅ This stops session timer on re-login
    save_session_data(current_user["username"])

    clock_in_button.configure(state="normal")
    clock_out_button.configure(state="disabled")

#
def delete_session_data(username):
    session_file = f"sessions/{username}_session.json"
    if os.path.exists(session_file):
        os.remove(session_file)  # ✅ This deletes the session data on clock out

#
def on_app_close():
    if start_time is not None:  # ✅ Active session check
        clock_out()  # ✅ Auto clock-out
    app.destroy()  # ✅ Close the window cleanly
#
app.protocol("WM_DELETE_WINDOW", on_app_close)
#

# user logs
def save_user_logs(username):
    log_filename = f"{username}_logs.csv"
    with open(log_filename, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Log'])
        for entry in clock_in_out_log:
            writer.writerow([entry])

def load_user_logs(username):
    global clock_in_out_log
    clock_in_out_log = []
    log_filename = f"{username}_logs.csv"
    if os.path.exists(log_filename):
        with open(log_filename, 'r', newline='') as file:
            reader = csv.reader(file)
            next(reader)  # Skip header
            for row in reader:
                clock_in_out_log.append(row[0])
    update_log_display()

# Function to update the clock-in/clock-out log display
def update_log_display():
    log_text = " \n"
    total_time = 0

    for log in clock_in_out_log:
        log_text += f"{log}\n"




    clock_in_out_log_label.configure(text=log_text)

#
def get_today_clock_counts():
    today_str = datetime.now().strftime("%b %d")
    clock_in_count = sum(1 for log in clock_in_out_log if log.startswith("Clocked in:") and today_str in log)
    clock_out_count = sum(1 for log in clock_in_out_log if log.startswith("Clocked out:") and today_str in log)
    return clock_in_count, clock_out_count

#
def save_session_data(username):
    session_data = {
        "start_time": start_time.strftime('%Y-%m-%d %H:%M:%S') if start_time else "",
        "today_total_seconds": str(today_total_seconds),
        "weekly_total_seconds": str(weekly_total_seconds)
    }

    with open(f"{username}_session.csv", "w", newline='') as file:
        writer = csv.DictWriter(file, fieldnames=session_data.keys())
        writer.writeheader()
        writer.writerow(session_data)

def load_session_data(username):
    global start_time, today_total_seconds, weekly_total_seconds

    filename = f"{username}_session.csv"
    if os.path.exists(filename):
        with open(filename, "r", newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                start_str = row.get("start_time", "")
                today_total_seconds = float(row.get("today_total_seconds", 0))
                weekly_total_seconds = float(row.get("weekly_total_seconds", 0))

                if start_str:
                    start_time = datetime.strptime(start_str, '%Y-%m-%d %H:%M:%S')

#
def save_user_avatar(username, avatar_filename):
    with open(f"{username}_avatar.json", "w") as file:
        json.dump({"avatar": avatar_filename}, file)
#
def load_user_avatar(username):
    global avatar_label  # make sure avatar_label is accessible
    avatar_file = f"{username}_avatar.json"
    if os.path.exists(avatar_file):
        with open(avatar_file, "r") as file:
            data = json.load(file)
            avatar_path = data.get("avatar", "")
            if avatar_path and os.path.exists(avatar_path):
                avatar_image = ctk.CTkImage(Image.open(avatar_path), size=(100, 100))
                avatar_label.configure(image=avatar_image, text="")
#
def change_avatar():
    filename = filedialog.askopenfilename(
        title="Choose Avatar",
        filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif")]
    )
    if filename:
        avatar_image = ctk.CTkImage(Image.open(filename), size=(100, 100))
        avatar_label.configure(image=avatar_image, text="")
        save_user_avatar(current_user["username"], filename)
#

# Assign functions to register and back to login
register_button.configure(command=show_register_frame)
back_to_login_button.configure(command=show_login_frame)
# Assign function to submit in register
submit_button.configure(command=register_user)
# Assign function to login button
login_button.configure(command=login_user)
# Assign function to clock in/out buttons
clock_in_button.configure(command=clock_in)
clock_out_button.configure(command=clock_out)
logout_button.configure(command=log_out)



app.mainloop()
